package za.ac.cput.DemoChapt.DemoChapt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoChaptApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoChaptApplication.class, args);
	}

}
